# NeuroGuard Professional Hackathon Prototype

## Included portals
- Patient login + dashboard
- Hospital login + command center
- Family live emergency dashboard
- Shared Emergency ID and synchronized browser localStorage state

## Demo credentials
Patient:
- ID: NG-PAT-10482
- Password: Neuro@123

Hospital:
- ID: HOSP-CN-002
- Password: Hospital@123

## 14 implemented demo data sources
1. Heart-rate sensor
2. SpO2 sensor
3. Accelerometer / arm drift
4. Face landmark analysis
5. Speech classifier
6. FAST questionnaire
7. GPS/location
8. Medical reports
9. Medication profile
10. Allergy profile
11. Hospital availability
12. Ambulance workflow
13. Family response
14. Symptom-onset timeline

These are simulated adapters/data streams in this static hackathon build. They are not connected to real medical devices or emergency services.

## Run
Double-click `index.html`, or from PowerShell:
`start index.html`

For best demo experience, use VS Code Live Server.

## Safety
This prototype is an AI-assisted emergency decision-support workflow, not a clinical diagnostic system. The 25 km hospital-routing concept is a configurable hackathon rule, not a medical guideline. Real ambulance/108 and hospital integrations require authorized APIs, consent, secure backend infrastructure, validation and regulatory review.

## Dark Hospital Edition additions
- Dark hospital command-center visual theme
- Ambulance details: simulated 108/ALS vehicle, crew, pickup, destination, ETA, GPS refresh and handoff workflow
- Medical report cards with secure-looking in-app preview
- Previous ECG, Medication Summary and Recent Blood Test demo records
- Patient, family and hospital ambulance views
- Time-limited report access / audit wording
