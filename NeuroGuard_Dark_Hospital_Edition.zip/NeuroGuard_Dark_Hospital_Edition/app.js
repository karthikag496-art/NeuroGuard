const DATA_SOURCES=[
["❤️","Heart-rate sensor","118 BPM","physiological"],["🫁","SpO₂ sensor","94%","physiological"],
["📱","Accelerometer","Arm drift","motion"],["🤳","Face landmarks","72% symmetry","vision"],
["🎤","Speech classifier","61% clarity","audio"],["🧠","FAST questionnaire","3 / 3","clinical-screen"],
["📍","GPS / location","8.2 km","location"],["📄","Medical reports","2 files","records"],
["💊","Medication profile","1 active","records"],["⚠️","Allergy profile","Penicillin","records"],
["🏥","Hospital availability","Available","coordination"],["🚑","Ambulance workflow","Connected","coordination"],
["👨‍👩‍👧","Family response","P1 notified","coordination"],["⏱️","Symptom onset","11:07 AM","timeline"]
];
const HOSPITALS=[
["City Neuro Hospital","18 Anna Nagar Main Road, Chennai","+91 44 4000 2200","8.2 km","AVAILABLE","Priority 1"],
["Metro Emergency Hospital","7 Mount Road, Chennai","+91 44 4000 3300","12.4 km","AVAILABLE","Priority 2"],
["St. Mary Stroke Centre","24 ABC Road, Chennai","+91 44 4000 1100","31.0 km","PREFERRED • >25 KM","Priority 3"]
];
const INITIAL_EVENTS=[
["11:07:12","Physiological anomaly detected","Heart-rate change triggered emergency screening."],
["11:07:18","Voice safety check started","10-second voice response window opened."],
["11:07:31","FAST screening completed","Face, arm and speech warning signals detected."],
["11:07:35","High-risk signal generated","NeuroGuard score: 82/100."],
["11:07:38","Family priority alert sent","Priority 1 contact notified."],
["11:08:04","Hospital search initiated","Preference, distance, capability and availability evaluated."]
];
function renderSources(){document.querySelectorAll("#sources").forEach(el=>el.innerHTML=DATA_SOURCES.map(x=>`<div class="source-row"><span class="src-icon">${x[0]}</span><div><b>${x[1]}</b><small>${x[3]}</small></div><span class="source-value">${x[2]}</span></div>`).join(""))}
function renderHospitals(){const el=document.getElementById("hospitals");if(!el)return;el.innerHTML=HOSPITALS.map((h,i)=>`<div class="hospital-item"><b>${h[0]}</b><p>${h[1]}</p><div class="hospital-meta"><span>📍 ${h[3]}</span><span>● ${h[4]}</span><span>${h[5]}</span></div></div>`).join("")}
function getEvents(){return JSON.parse(localStorage.getItem("ng_events")||JSON.stringify(INITIAL_EVENTS))}
function renderTimeline(){document.querySelectorAll("#timeline").forEach(el=>el.innerHTML=getEvents().map(e=>`<div class="event"><b>${e[1]}</b><span>${e[0]}</span><p>${e[2]}</p></div>`).join(""))}
function addEvent(title,desc){const ev=getEvents();const now=new Date();const t=now.toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",second:"2-digit"});ev.push([t,title,desc]);localStorage.setItem("ng_events",JSON.stringify(ev));renderTimeline();const s=document.getElementById("timelineStatus");if(s)s.textContent="ACTIVE"}
function startEmergency(){addEvent("Emergency screening activated","Patient initiated smartphone FAST workflow.");alert("Emergency screening started. Multi-source signal fusion is now active.");}
function acceptHospital(){addEvent("Hospital accepted emergency","City Neuro Hospital accepted NG-2026-10482. Stroke team preparation initiated.");alert("Emergency accepted. Patient, family and ambulance workflow have been notified.");}
function confirmArrival(){addEvent("Patient arrived at hospital","Hospital staff confirmed patient arrival. Emergency record updated.");alert("Patient arrival confirmed. Patient and family notification sent.");}
function notifyPatient(){addEvent("Hospital details shared","Accepted hospital address and contact details shared through emergency workflow.");alert("Hospital details sent to patient/family in the demo.");}
function prepareTeam(){addEvent("Stroke team marked prepared","Hospital team acknowledged incoming high-risk emergency.");alert("Stroke team marked as prepared.");}
function changeLang(v){const t=document.getElementById("aiText");if(v==="ta")t.textContent="அமைதியாக இருங்கள். உங்கள் emergency contact மற்றும் மருத்துவமனைக்கு தகவல் அனுப்பப்பட்டுள்ளது. தயவுசெய்து அமர்ந்திருங்கள்.";else if(v==="hi")t.textContent="शांत रहें। आपके आपातकालीन संपर्क और अस्पताल को सूचना भेज दी गई है। कृपया बैठे रहें और चिकित्सा निर्देशों का पालन करें।";else t.textContent="You’re doing the right thing. Stay calm, remain seated, and follow emergency medical instructions."}
function logout(){sessionStorage.clear();location.href="index.html"}
renderSources();renderHospitals();renderTimeline();
function previewReport(name){const m=document.getElementById("reportModal");const t=document.getElementById("reportTitle");if(m){t.textContent=name;m.classList.add("open")}}
function closeReport(){const m=document.getElementById("reportModal");if(m)m.classList.remove("open")}
